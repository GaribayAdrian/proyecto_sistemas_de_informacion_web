<?php

require_once "../conexion.php";

$sql = "SELECT
            c.*,
            p.nombre_proveedor
        FROM compras c
        LEFT JOIN proveedores p
        ON c.id_proveedor = p.id_proveedor
        ORDER BY c.id_compra";

$stmt = $conexion->prepare($sql);
$stmt->execute();

$compras = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html>
<head>

<title>Compras</title>

<link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

<h1>Listado de Compras</h1>

<a class="btn btn-agregar"
href="agregar.php">

➕ Agregar Compra

</a>

<a class="btn btn-home"
href="../dashboard.php">

🏠 Inicio

</a>

<br><br>

<table>

<tr>

<th>Fecha</th>
<th>Total</th>
<th>Proveedor</th>
<th>Editar</th>
<th>Eliminar</th>

</tr>

<?php foreach($compras as $compra){ ?>

<tr>

<td><?= $compra['fecha']; ?></td>

<td>$<?= number_format($compra['total_compra'],2); ?></td>

<td><?= $compra['nombre_proveedor']; ?></td>

<td>

<a class="btn btn-editar"

href="editar.php?id=<?= $compra['id_compra']; ?>">

✏️ Editar

</a>

</td>

<td>

<a class="btn btn-eliminar"

href="eliminar.php?id=<?= $compra['id_compra']; ?>">

🗑️ Eliminar

</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>