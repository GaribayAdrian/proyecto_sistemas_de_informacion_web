<?php

session_start();

require_once "../conexion.php";

$id = $_GET['id'];


$sql = "SELECT *
        FROM proveedores
        ORDER BY nombre_proveedor";

$stmt = $conexion->prepare($sql);
$stmt->execute();

$proveedores = $stmt->fetchAll(PDO::FETCH_ASSOC);


$sql = "SELECT *
        FROM compras
        WHERE id_compra = :id";

$stmt = $conexion->prepare($sql);
$stmt->execute([
    ':id' => $id
]);

$compra = $stmt->fetch(PDO::FETCH_ASSOC);


if(isset($_POST['actualizar'])){

    $sql = "UPDATE compras
            SET fecha = :fecha,
                total_compra = :total,
                id_proveedor = :proveedor,
                fecha_modificacion = CURRENT_TIMESTAMP,
                usuario_modificacion = :usuario
            WHERE id_compra = :id";

    $stmt = $conexion->prepare($sql);

    $stmt->execute([

        ':fecha' => $_POST['fecha'],
        ':total' => $_POST['total_compra'],
        ':proveedor' => $_POST['id_proveedor'],
        ':usuario' => $_SESSION['nombre'],
        ':id' => $id

    ]);

    header("Location: listar.php");
    exit();
}

?>

<!DOCTYPE html>
<html>

<head>

<title>Editar Compra</title>

<link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

<h1>Editar Compra</h1>

<form method="POST">

Fecha

<br>

<input
type="date"
name="fecha"
value="<?= $compra['fecha']; ?>"
required>

<br><br>

Total

<br>

<input
type="number"
step="0.01"
name="total_compra"
value="<?= $compra['total_compra']; ?>"
required>

<br><br>

Proveedor

<br>

<select
name="id_proveedor"
required>

<?php foreach($proveedores as $proveedor){ ?>

<option
value="<?= $proveedor['id_proveedor']; ?>"

<?php
if($proveedor['id_proveedor'] == $compra['id_proveedor']){
    echo "selected";
}
?>

>

<?= $proveedor['nombre_proveedor']; ?>

</option>

<?php } ?>

</select>

<br><br>

<button
class="btn btn-agregar"
type="submit"
name="actualizar">

💾 Actualizar

</button>

<a
class="btn btn-editar"
href="listar.php">

⬅ Volver

</a>

<a
class="btn btn-home"
href="../dashboard.php">

🏠 Inicio

</a>

</form>

</div>

</body>

</html>