<?php

session_start();

require_once "../conexion.php";

$sql = "SELECT *
        FROM proveedores
        ORDER BY nombre_proveedor";

$stmt = $conexion->prepare($sql);
$stmt->execute();

$proveedores = $stmt->fetchAll(PDO::FETCH_ASSOC);

if(isset($_POST['guardar'])){

    $sql = "INSERT INTO compras
    (
        fecha,
        total_compra,
        id_proveedor,
        usuario_creacion
    )
    VALUES
    (
        :fecha,
        :total,
        :proveedor,
        :usuario
    )";

    $stmt = $conexion->prepare($sql);

    $stmt->execute([

        ':fecha' => $_POST['fecha'],
        ':total' => $_POST['total_compra'],
        ':proveedor' => $_POST['id_proveedor'],
        ':usuario' => $_SESSION['nombre']

    ]);

    header("Location: listar.php");
    exit();
}

?>

<!DOCTYPE html>

<html>

<head>

<title>Agregar Compra</title>

<link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

<h1>Agregar Compra</h1>

<form method="POST">

Fecha

<br>

<input
type="date"
name="fecha"
required>

<br><br>

Total

<br>

<input
type="number"
step="0.01"
name="total_compra"
required>

<br><br>

Proveedor

<br>

<select
name="id_proveedor"
required>

<option value="">Seleccione un proveedor</option>

<?php foreach($proveedores as $proveedor){ ?>

<option
value="<?= $proveedor['id_proveedor']; ?>">

<?= $proveedor['nombre_proveedor']; ?>

</option>

<?php } ?>

</select>

<br><br>

<button
class="btn btn-agregar"
type="submit"
name="guardar">

💾 Guardar

</button>

<a
class="btn btn-editar"
href="listar.php">

⬅ Volver

</a>

<a
class="btn btn-home"
href="../dashboard.php">

🏠 Inicio

</a>

</form>

</div>

</body>

</html>