<?php

session_start();

require_once "../conexion.php";

if(isset($_POST['guardar'])){

    $sql = "INSERT INTO clientes
    (
        nombre_cliente,
        telefono,
        correo,
        direccion,
        usuario_creacion
    )
    VALUES
    (
        :nombre,
        :telefono,
        :correo,
        :direccion,
        :usuario
    )";

    $stmt = $conexion->prepare($sql);

    $stmt->execute([
        ':nombre' => $_POST['nombre_cliente'],
        ':telefono' => $_POST['telefono'],
        ':correo' => $_POST['correo'],
        ':direccion' => $_POST['direccion'],
        ':usuario' => $_SESSION['nombre']
    ]);
        $id = $conexion->lastInsertId();

    header("Location: listar.php");
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Agregar Cliente</title>
<link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<h1>Agregar Cliente</h1>

<form method="POST">

Nombre<br>
<input type="text" name="nombre_cliente" required>
<br><br>

Teléfono<br>
<input type="text" name="telefono">
<br><br>

Correo<br>
<input type="email" name="correo">
<br><br>

Dirección<br>
<input type="text" name="direccion">
<br><br>


<button class="btn btn-agregar"
        type="submit"
        name="guardar">

💾 Guardar

</button>

<a class="btn btn-editar"
   href="listar.php">

⬅ Volver

</a>

</form>

</div>

</form>

</body>
</html>