<?php

session_start();

require_once "../conexion.php";

$id = $_GET['id'];

$sql = "SELECT * FROM clientes
        WHERE id_cliente = :id";

$stmt = $conexion->prepare($sql);
$stmt->execute([':id'=>$id]);

$cliente = $stmt->fetch(PDO::FETCH_ASSOC);

if(isset($_POST['actualizar'])){

    $sql = "UPDATE clientes
            SET nombre_cliente = :nombre,
                telefono = :telefono,
                correo = :correo,
                direccion = :direccion,
                fecha_modificacion = CURRENT_TIMESTAMP,
                usuario_modificacion = :usuario
            WHERE id_cliente = :id";

    $stmt = $conexion->prepare($sql);

    $stmt->execute([
        ':nombre' => $_POST['nombre_cliente'],
        ':telefono' => $_POST['telefono'],
        ':correo' => $_POST['correo'],
        ':direccion' => $_POST['direccion'],
        ':usuario' => $_SESSION['nombre'],
        ':id' => $id
    ]);

    header("Location: listar.php");
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Editar Cliente</title>
<link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<h1>Editar Cliente</h1>

<form method="POST">

Nombre<br>
<input type="text"
name="nombre_cliente"
value="<?= $cliente['nombre_cliente']; ?>">
<br><br>

Teléfono<br>
<input type="text"
name="telefono"
value="<?= $cliente['telefono']; ?>">
<br><br>

Correo<br>
<input type="email"
name="correo"
value="<?= $cliente['correo']; ?>">
<br><br>

Dirección<br>
<input type="text"
name="direccion"
value="<?= $cliente['direccion']; ?>">
<br><br>

<button type="submit" name="actualizar">
Actualizar
</button>

</form>

</body>
</html>