<?php

require_once "../conexion.php";

$sql = "SELECT * FROM clientes
        ORDER BY id_cliente";

$stmt = $conexion->prepare($sql);
$stmt->execute();

$clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Clientes</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<h1>Listado de Clientes</h1>

<a class="btn btn-agregar" href="agregar.php">
➕ Agregar Cliente
</a>
<a class="btn btn-home"
   href="../dashboard.php">

🏠 Inicio

</a>
<br><br>

<table border="1">

<tr>
    <th>Nombre</th>
    <th>Teléfono</th>
    <th>Correo</th>
    <th>Dirección</th>
    <th>Editar</th>
    <th>Eliminar</th>
</tr>

<?php foreach($clientes as $cliente){ ?>

<tr>

<td><?= $cliente['nombre_cliente']; ?></td>
<td><?= $cliente['telefono']; ?></td>
<td><?= $cliente['correo']; ?></td>
<td><?= $cliente['direccion']; ?></td>

<td>
<a class="btn btn-editar"
href="editar.php?id=<?php echo $cliente['id_cliente']; ?>">
✏️Editar
</a>
</td>

<td>
<a class="btn btn-eliminar"
href="eliminar.php?id=<?php echo $cliente['id_cliente']; ?>">
🗑️Eliminar
</a>
</td>

</tr>

<?php } ?>

</table>

</body>
</html>