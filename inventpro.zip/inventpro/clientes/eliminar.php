<?php

require_once "../conexion.php";

$id = $_GET['id'];

$sql = "DELETE FROM clientes
        WHERE id_cliente = :id";

$stmt = $conexion->prepare($sql);

$stmt->execute([
    ':id' => $id
]);

header("Location: listar.php");
exit();

?><?php

require_once "../conexion.php";

$id = $_GET['id'];

$sql = "DELETE FROM clientes
        WHERE id_cliente = :id";

$stmt = $conexion->prepare($sql);

$stmt->execute([
    ':id' => $id
]);

header("Location: listar.php");
exit();

?>