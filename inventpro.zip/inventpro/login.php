<?php

session_start();
require_once "conexion.php";

if(isset($_POST['login'])){

    $correo = trim($_POST['correo']);
    $contrasena = trim($_POST['contrasena']);

    $sql = "SELECT *
            FROM usuarios
            WHERE correo = :correo";

    $stmt = $conexion->prepare($sql);
    $stmt->bindParam(':correo', $correo);
    $stmt->execute();

    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if($usuario && password_verify($contrasena, $usuario['contrasena'])){

        $_SESSION['id_usuario'] = $usuario['id_usuario'];
        $_SESSION['nombre'] = $usuario['nombre'];
        $_SESSION['correo'] = $usuario['correo'];
        $_SESSION['rol'] = $usuario['rol'];

        header("Location: dashboard.php");
        exit();

    }else{

        $mensaje = "Correo o contraseña incorrectos.";

    }

}

?>

<!DOCTYPE html>
<html>
<head>

    <title>InventPro</title>

    <link rel="stylesheet" href="css/estilos.css">

</head>

<body>

<div class="contenedor">

    <img
        src="img/logo.png"
        class="logo"
        alt="InventPro">

    <h1>InventPro</h1>

    <?php
    if(isset($mensaje)){
        echo "<p style='color:red;'>$mensaje</p>";
    }
    ?>

    <form method="POST">

        <label>Correo</label><br>

        <input
            type="email"
            name="correo"
            required>

        <br><br>

        <label>Contraseña</label><br>

        <input
            type="password"
            name="contrasena"
            required>

        <br><br>

        <button
            class="btn btn-agregar"
            type="submit"
            name="login">

            Iniciar Sesión

        </button>

    </form>

</div>

</body>
</html>