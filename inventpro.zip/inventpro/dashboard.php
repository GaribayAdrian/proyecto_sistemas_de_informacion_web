<?php

session_start();

if(!isset($_SESSION['id_usuario'])){

    header("Location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>

<div class="navbar">
       Bienvenido:
     <strong><?php echo $_SESSION['nombre']; ?></strong>

     <br>

     Rol:
     <strong><?php echo $_SESSION['rol']; ?></strong>
</div>

</div>
<div style="text-align:right; margin-bottom:20px;">

    <a class="btn-salir" href="logout.php">
        Cerrar Sesión
    </a>

</div>

<div class="dashboard">

    <img
        src="img/logo.png"
        class="logo"
        alt="InventPro">

    <h1>InventPro</h1>

    <h3>Sistema de Inventario y Ventas</h3>

</div>




<hr>
<div class="menu">

    <div class="tarjeta">
        <a href="productos/listar.php">📦 Productos</a>
        <p>Administrar inventario</p>
    </div>

    <div class="tarjeta">
        <a href="clientes/listar.php">👤 Clientes</a>
        <p>Administrar clientes</p>
    </div>

    <div class="tarjeta">
        <a href="categorias/listar.php">🏷️ Categorías</a>
        <p>Clasificación de productos</p>
    </div>

        <div class="tarjeta">
        <a href="proveedores/listar.php">🚚 Proveedores</a>
        <p>Administrar proveedores</p>
    </div>
        <div class="tarjeta">
        <a href="compras/listar.php">🧾 Compras</a>
        <p>Visualizar compras</p>
    </div>
        <div class="tarjeta">
        <a href="usuarios/listar.php">🧑‍💻 Usuarios</a>
        <p>Visualizar usuarios</p>
    </div>
    
        <div class="tarjeta">
        <a href="ventas/listar.php">💲 Ventas</a>
        <p>Historial de Ventas</p>
    </div>
    




</div>

</body>
</html>

