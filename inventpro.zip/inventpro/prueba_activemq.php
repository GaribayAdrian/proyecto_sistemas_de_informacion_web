<?php

require __DIR__ . '/vendor/autoload.php';

use Stomp\Client;
use Stomp\StatefulStomp;
use Stomp\Transport\Message;

try {

   $client = new Client('tcp://127.0.0.1:61613');
    $client->setLogin('admin', 'admin');

    $stomp = new StatefulStomp($client);

    $contenido = json_encode([
        'producto' => 'Laptop Dell',
        'stock' => 2,
        'evento' => 'stock_bajo',
        'fecha' => date('Y-m-d H:i:s')
    ]);

    $mensaje = new Message($contenido);

    $stomp->send('/queue/inventpro.stock', $mensaje);

    echo "✅ Mensaje enviado correctamente";

} catch (Exception $e) {

    echo "❌ Error: " . $e->getMessage();

}