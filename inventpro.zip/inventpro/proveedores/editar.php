<?php

session_start();

require_once "../conexion.php";

$id = $_GET['id'];

$sql = "SELECT * FROM proveedores
        WHERE id_proveedor = :id";

$stmt = $conexion->prepare($sql);
$stmt->execute([':id'=>$id]);

$proveedor = $stmt->fetch(PDO::FETCH_ASSOC);

if(isset($_POST['actualizar'])){

    $sql = "UPDATE proveedores
            SET nombre_proveedor = :nombre,
                telefono = :telefono,
                correo_proveedor = :correo,
                direccion = :direccion,
                fecha_modificacion = CURRENT_TIMESTAMP,
                usuario_modificacion = :usuario
            WHERE id_proveedor = :id";

    $stmt = $conexion->prepare($sql);

    $stmt->execute([
        ':nombre' => $_POST['nombre_proveedor'],
        ':telefono' => $_POST['telefono'],
        ':correo' => $_POST['correo_proveedor'],
        ':direccion' => $_POST['direccion'],
        ':usuario' => $_SESSION['nombre'],
        ':id' => $id
    ]);

    header("Location: listar.php");
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Editar Proveedor</title>
<link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<h1>Editar Proveedor</h1>

<form method="POST">

Nombre<br>
<input type="text"
name="nombre_proveedor"
value="<?= $proveedor['nombre_proveedor']; ?>">
<br><br>

Teléfono<br>
<input type="text"
name="telefono"
value="<?= $proveedor['telefono']; ?>">
<br><br>

Correo<br>
<input type="email"
name="correo_proveedor"
value="<?= $proveedor['correo_proveedor']; ?>">
<br><br>

Dirección<br>
<input type="text"
name="direccion"
value="<?= $proveedor['direccion']; ?>">
<br><br>

<button type="submit" name="actualizar">
Actualizar
</button>

</form>

</body>
</html>