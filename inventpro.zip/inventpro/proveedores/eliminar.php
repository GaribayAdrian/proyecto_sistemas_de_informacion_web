<?php

require_once "../conexion.php";

$id = $_GET['id'];

$sql = "DELETE FROM proveedores
        WHERE id_proveedor = :id";

$stmt = $conexion->prepare($sql);

$stmt->execute([
    ':id' => $id
]);

header("Location: listar.php");
exit();

?><?php

require_once "../conexion.php";

$id = $_GET['id'];

$sql = "DELETE FROM proveedores
        WHERE id_proveedores = :id";

$stmt = $conexion->prepare($sql);

$stmt->execute([
    ':id' => $id
]);

header("Location: listar.php");
exit();

?>