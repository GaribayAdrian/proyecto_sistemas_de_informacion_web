<?php

require_once "../conexion.php";

$sql = "SELECT * FROM proveedores
        ORDER BY id_proveedor";

$stmt = $conexion->prepare($sql);
$stmt->execute();

$proveedores = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Proveedores</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<h1>Listado de Proveedores</h1>

<a class="btn btn-agregar" href="agregar.php">
➕ Agregar Proveedor
</a>
<a class="btn btn-home"
   href="../dashboard.php">

🏠 Inicio

</a>
<br><br>

<table border="1">

<tr>
    <th>Nombre</th>
    <th>Teléfono</th>
    <th>Correo</th>
    <th>Dirección</th>
    <th>Editar</th>
    <th>Eliminar</th>
</tr>

<?php foreach($proveedores as $proveedor){ ?>

<tr>

<td><?= $proveedor['nombre_proveedor']; ?></td>
<td><?= $proveedor['telefono']; ?></td>
<td><?= $proveedor['correo_proveedor']; ?></td>
<td><?= $proveedor['direccion']; ?></td>

<td>
<a class="btn btn-editar"
href="editar.php?id=<?php echo $proveedor['id_proveedor']; ?>">
✏️Editar
</a>
</td>

<td>
<a class="btn btn-eliminar"
href="eliminar.php?id=<?php echo $proveedor['id_proveedor']; ?>">
🗑️Eliminar
</a>
</td>

</tr>

<?php } ?>

</table>

</body>
</html>