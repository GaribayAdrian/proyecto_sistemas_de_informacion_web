<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "localhost";
$port = "5432";
$dbname = "inventpro";   // cambia si tu BD tiene otro nombre
$user = "postgres";
$password = "1234";

try {

    $conexion = new PDO(
        "pgsql:host=$host;port=$port;dbname=$dbname",
        $user,
        $password
    );

    $conexion->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );

    

}
catch(PDOException $e){

    echo "Error de conexión: " . $e->getMessage();
}

?>