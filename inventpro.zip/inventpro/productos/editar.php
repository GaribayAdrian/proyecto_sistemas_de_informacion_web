<?php

session_start();

require_once "../conexion.php";

$id = $_GET['id'];

$sql = "SELECT * FROM productos
        WHERE id_producto = :id";

$stmt = $conexion->prepare($sql);
$stmt->execute([':id' => $id]);

$producto = $stmt->fetch(PDO::FETCH_ASSOC);

if(isset($_POST['actualizar'])){

    $nombre = $_POST['nombre_producto'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $stock = $_POST['stock'];
    $categoria = $_POST['id_categoria'];

    $sql = "UPDATE productos
            SET nombre_producto = :nombre,
                descripcion = :descripcion,
                precio = :precio,
                stock = :stock,
                id_categoria = :categoria,
                fecha_modificacion = CURRENT_TIMESTAMP,
                usuario_modificacion = :usuario,
            WHERE id_producto = :id";

    $stmt = $conexion->prepare($sql);

    $stmt->execute([
        ':nombre' => $nombre,
        ':descripcion' => $descripcion,
        ':precio' => $precio,
        ':stock' => $stock,
        ':categoria' => $categoria,
        ':usuario' => $_SESSION['nombre'],
        ':id' => $id
    ]);

    header("Location: listar.php");
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Editar Producto</title>
<link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<h1>Editar Producto</h1>

<form method="POST">

Nombre<br>
<input type="text"
name="nombre_producto"
value="<?php echo $producto['nombre_producto']; ?>">
<br><br>

Descripción<br>
<input type="text"
name="descripcion"
value="<?php echo $producto['descripcion']; ?>">
<br><br>

Precio<br>
<input type="number"
step="0.01"
name="precio"
value="<?php echo $producto['precio']; ?>">
<br><br>

Stock<br>
<input type="number"
name="stock"
value="<?php echo $producto['stock']; ?>">
<br><br>

Categoría<br>
<input type="number"
name="id_categoria"
value="<?php echo $producto['id_categoria']; ?>">
<br><br>

<button type="submit" name="actualizar">
Actualizar
</button>

</form>

</body>
</html>