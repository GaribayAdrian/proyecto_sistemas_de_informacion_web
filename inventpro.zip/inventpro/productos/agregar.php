<?php

session_start();

require_once "../conexion.php";
require_once "../vendor/autoload.php";

use Stomp\Client;
use Stomp\StatefulStomp;
use Stomp\Transport\Message;

$sqlCategorias = "SELECT * FROM categorias
                  ORDER BY nombre_categoria";

$stmtCategorias = $conexion->prepare($sqlCategorias);
$stmtCategorias->execute();

$categorias = $stmtCategorias->fetchAll(PDO::FETCH_ASSOC);

if(isset($_POST['guardar'])){
    $nombre = $_POST['nombre_producto'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $stock = $_POST['stock'];
    $categoria = $_POST['id_categoria'];

    $sql = "INSERT INTO productos
    (
    
        nombre_producto,
        descripcion,
        precio,
        stock,
        id_categoria,
        usuario_creacion
    )
    VALUES
    (
        :nombre,
        :descripcion,
        :precio,
        :stock,
        :categoria,
        :usuario
    )";

    $stmt = $conexion->prepare($sql);

    $stmt->execute([
        ':nombre' => $nombre,
        ':descripcion' => $descripcion,
        ':precio' => $precio,
        ':stock' => $stock,
        ':categoria' => $categoria,
        ':usuario' => $_SESSION['nombre']
        
    ]);
    $id = $conexion->lastInsertId();
    try {

    $client = new Client('tcp://127.0.0.1:61613');
    $client->setLogin('admin', 'admin');

    $stomp = new StatefulStomp($client);

    $contenido = json_encode([
        'evento' => 'producto_creado',
        'id_producto' => $id,
        'producto' => $nombre,
        'stock' => $stock,
        'precio' => $precio,
        'fecha' => date('Y-m-d H:i:s')
    ]);

    $mensaje = new Message($contenido);

    $stomp->send('/queue/inventpro.stock', $mensaje);

} catch (Exception $e) {

    error_log("Error ActiveMQ: " . $e->getMessage());

}

    header("Location: listar.php");
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Agregar Producto</title>
<link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<h1>Agregar Producto</h1>

<form method="POST">


Nombre<br>
<input type="text" name="nombre_producto" required>
<br><br>

Descripción<br>
<input type="text" name="descripcion">
<br><br>

Precio<br>
<input type="number" step="0.01" name="precio">
<br><br>

Stock<br>
<input type="number" name="stock">
<br><br>

Categoría<br>

<select name="id_categoria" required>

<option value="">
Seleccione una categoría
</option>

<?php foreach($categorias as $categoria){ ?>

<option value="<?= $categoria['id_categoria']; ?>">

<?= $categoria['nombre_categoria']; ?>

</option>

<?php } ?>

</select>

<button class="btn btn-agregar"
        type="submit"
        name="guardar">

💾 Guardar

</button>

<a class="btn btn-editar"
   href="listar.php">

⬅ Volver

</a>

</form>

</body>
</html>