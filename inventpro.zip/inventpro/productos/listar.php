<?php

session_start();

require_once "../conexion.php";

$sql = "SELECT
            p.*,
            c.nombre_categoria
        FROM productos p
        LEFT JOIN categorias c
        ON p.id_categoria = c.id_categoria
        ORDER BY p.id_producto";

$stmt = $conexion->prepare($sql);
$stmt->execute();

$productos = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Productos</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<h1>Listado de Productos</h1>

<a class="btn btn-agregar" href="agregar.php">
➕ Agregar Producto
</a>
<a class="btn btn-home"
   href="../dashboard.php">

🏠 Inicio

</a>

<br><br>

<table border="1">

<tr>
    <th>Nombre</th>
    <th>Categoría</th>
    <th>Precio</th>
    <th>Stock</th>
    <th>Editar</th>
    <th>Eliminar</th>
</tr>

<?php foreach($productos as $producto){ ?>

<tr>


<td><?php echo $producto['nombre_producto']; ?></td>

<td><?php echo $producto['nombre_categoria']; ?></td>

<td><?php echo $producto['precio']; ?></td>

<td><?php echo $producto['stock']; ?></td>

<td>
<a class="btn btn-editar"
href="editar.php?id=<?php echo $producto['id_producto']; ?>">
✏️ Editar
</a>
</td>


<td>
<a class="btn btn-eliminar"
href="eliminar.php?id=<?php echo $producto['id_producto']; ?>">
🗑️ Eliminar
</a>
</td>


</tr>

<?php } ?>

</table>

</body>
</html>