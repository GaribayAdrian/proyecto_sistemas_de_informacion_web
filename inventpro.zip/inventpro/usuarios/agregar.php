<?php

session_start();

require_once "../conexion.php";

if(isset($_POST['guardar'])){

    $sql = "INSERT INTO usuarios
    (
        nombre,
        correo,
        contrasena,
        rol,
        usuario_creacion
    )
    VALUES
    (
        :nombre,
        :correo,
        :contrasena,
        :rol,
        :usuario
    )";

    $stmt = $conexion->prepare($sql);
    $contrasena = password_hash($_POST['contrasena'], PASSWORD_DEFAULT);

    $stmt->execute([

        ':nombre' => $_POST['nombre'],
        ':correo' => $_POST['correo'],
        ':rol' => $_POST['rol'],
        ':contrasena' => $contrasena,
        ':usuario' => $_SESSION['nombre']

    ]);

    header("Location: listar.php");
    exit();
}

?>

<!DOCTYPE html>

<html>

<head>

<title>Agregar Usuario</title>

<link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

<h1>Agregar Usuario</h1>

<form method="POST">

Nombre

<br>

<input
type="text"
name="nombre"
required>

<br><br>

Correo

<br>

<input
type="email"
name="correo"
required>

<br><br>

Contraseña

<br>

<input
type="password"
name="contrasena"
required>

<br><br>

Rol

<br>

<select
name="rol"
required>

<option value="">Seleccione...</option>

<option value="Administrador">

Administrador

</option>

<option value="Empleado">

Empleado

</option>

</select>

<br><br>

<button
class="btn btn-agregar"
type="submit"
name="guardar">

💾 Guardar

</button>

<a
class="btn btn-editar"
href="listar.php">

⬅ Volver

</a>

<a
class="btn btn-home"
href="../dashboard.php">

🏠 Inicio

</a>

</form>

</div>

</body>

</html>