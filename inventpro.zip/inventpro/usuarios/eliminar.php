<?php

require_once "../conexion.php";

$id = $_GET['id'];

$sql = "DELETE FROM usuarios
        WHERE id_usuario = :id";

$stmt = $conexion->prepare($sql);

$stmt->execute([
    ':id' => $id
]);

header("Location: listar.php");
exit();

?><?php

require_once "../conexion.php";

$id = $_GET['id'];

$sql = "DELETE FROM usuarios
        WHERE id_usuarios = :id";

$stmt = $conexion->prepare($sql);

$stmt->execute([
    ':id' => $id
]);

header("Location: listar.php");
exit();

?>