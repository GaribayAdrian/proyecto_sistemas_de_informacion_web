<?php

require_once "../conexion.php";

$sql = "SELECT *
        FROM usuarios
        ORDER BY id_usuario";

$stmt = $conexion->prepare($sql);
$stmt->execute();

$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html>

<head>

<title>Usuarios</title>

<link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

<h1>Listado de Usuarios</h1>

<a class="btn btn-agregar"
href="agregar.php">

➕ Agregar Usuario

</a>

<a class="btn btn-home"
href="../dashboard.php">

🏠 Inicio

</a>

<br><br>

<table>

<tr>

<th>Nombre</th>
<th>Correo</th>
<th>Rol</th>
<th>Editar</th>
<th>Eliminar</th>

</tr>

<?php foreach($usuarios as $usuario){ ?>

<tr>

<td><?= $usuario['nombre']; ?></td>

<td><?= $usuario['correo']; ?></td>

<td><?= $usuario['rol']; ?></td>

<td>

<a
class="btn btn-editar"
href="editar.php?id=<?= $usuario['id_usuario']; ?>">

✏️ Editar

</a>

</td>

<td>

<a
class="btn btn-eliminar"
href="eliminar.php?id=<?= $usuario['id_usuario']; ?>">

🗑️ Eliminar

</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</body>

</html>