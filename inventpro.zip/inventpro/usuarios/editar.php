<?php

session_start();

require_once "../conexion.php";

$id = $_GET['id'];

$sql = "SELECT * FROM usuarios
        WHERE id_usuario = :id";

$stmt = $conexion->prepare($sql);
$stmt->execute([':id'=>$id]);

$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if(isset($_POST['actualizar'])){

    $sql = "UPDATE usuarios
            SET nombre = :nombre,
                correo = :correo,
                contrasena = :contrasena,
                rol = :rol,
                fecha_modificacion = CURRENT_TIMESTAMP,
                usuario_modificacion = :usuario
            WHERE id_usuario = :id";

    $stmt = $conexion->prepare($sql);
    $contrasena = password_hash($_POST['contrasena'], PASSWORD_DEFAULT);

    $stmt->execute([
        ':nombre' => $_POST['nombre'],
        ':correo' => $_POST['correo'],
        ':contrasena' => $contrasena,
        ':rol' => $_POST['rol'],
        ':usuario' => $_SESSION['nombre'],
        ':id' => $id
        
    ]);

    header("Location: listar.php");
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Editar Usuario</title>
<link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<h1>Editar Usuario</h1>

<form method="POST">

Nombre<br>
<input type="text"
name="nombre"
value="<?= $usuario['nombre']; ?>">
<br><br>

Correo<br>
<input type="email"
name="correo"
value="<?= $usuario['correo']; ?>">
<br><br>

Contraseña<br>
<input type="text"
name="contrasena"
value="<?= $usuario['contrasena']; ?>">
<br><br>

Rol<br>
<input type="text"
name="rol"
value="<?= $usuario['rol']; ?>">
<br><br>

<button type="submit" name="actualizar">
Actualizar
</button>

</form>

</body>
</html>