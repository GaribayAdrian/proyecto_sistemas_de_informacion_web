<?php

require_once "../conexion.php";

$id = $_GET['id'];

$sql = "DELETE FROM categorias
        WHERE id_categoria = :id";

$stmt = $conexion->prepare($sql);

$stmt->execute([
    ':id' => $id
]);

header("Location: listar.php");
exit();

?>