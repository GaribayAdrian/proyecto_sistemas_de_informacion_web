<?php

session_start();

require_once "../conexion.php";

$id = $_GET['id'];

$sql = "SELECT * FROM categorias
        WHERE id_categoria = :id";

$stmt = $conexion->prepare($sql);
$stmt->execute([':id'=>$id]);

$categoria = $stmt->fetch(PDO::FETCH_ASSOC);

if(isset($_POST['actualizar'])){

    $sql = "UPDATE categorias
            SET nombre_categoria = :nombre,
                descripcion = :descripcion,
                usuario_modificacion = :usuario,
                fecha_modificacion = CURRENT_TIMESTAMP
            WHERE id_categoria = :id";

    $stmt = $conexion->prepare($sql);

    $stmt->execute([
        ':nombre' => $_POST['nombre_categoria'],
        ':descripcion' => $_POST['descripcion'],
        ':usuario' => $_SESSION['nombre'],
        ':id' => $id
    ]);

    header("Location: listar.php");
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Editar Categoría</title>
<link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

<h1>Editar Categoría</h1>

<form method="POST">

Nombre<br>
<input type="text"
name="nombre_categoria"
value="<?= $categoria['nombre_categoria']; ?>">
<br><br>

Descripción<br>
<input type="text"
name="descripcion"
value="<?= $categoria['descripcion']; ?>">
<br><br>

<button type="submit" name="actualizar">
Actualizar
</button>

</form>

</body>
</html>