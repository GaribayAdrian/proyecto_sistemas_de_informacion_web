<?php

require_once "../conexion.php";

$sql = "SELECT * FROM categorias
        ORDER BY id_categoria";

$stmt = $conexion->prepare($sql);
$stmt->execute();

$categorias = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html>
<head>
   
    <title>Categorías</title>
    <link rel="stylesheet" href="../css/estilos.css">

</head>
<body>

<h1>Listado de Categorías</h1>

<a class="btn btn-agregar" href="agregar.php">
➕ Agregar Categoria
</a>
<a class="btn btn-home"
   href="../dashboard.php">

🏠 Inicio

</a>

<br><br>

<table border="1">

<tr>
    <th>Nombre</th>
    <th>Descripción</th>
    <th>Editar</th>
    <th>Eliminar</th>
</tr>

<?php foreach($categorias as $categoria){ ?>

<tr>


<td><?= $categoria['nombre_categoria']; ?></td>

<td><?= $categoria['descripcion']; ?></td>

<td>
<a class="btn btn-editar"
href="editar.php?id=<?php echo $categoria['id_categoria']; ?>">
✏️ Editar
</a>
</td>

<td>
<a class="btn btn-eliminar"
href="eliminar.php?id=<?php echo $categoria['id_categoria']; ?>">
🗑️ Eliminar
</a>
</td>

</tr>

<?php } ?>

</table>

</body>
</html>
<link rel="stylesheet" href="../css/estilos.css">