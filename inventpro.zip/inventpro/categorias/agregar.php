<?php

session_start();

require_once "../conexion.php";

if(isset($_POST['guardar'])){

    $sql = "INSERT INTO categorias
            (
                nombre_categoria,
                descripcion,
                usuario_creacion
            )
            VALUES
            (
                :nombre,
                :descripcion,
                :usuario
            )";

    $stmt = $conexion->prepare($sql);

    $stmt->execute([
        ':nombre' => $_POST['nombre_categoria'],
        ':descripcion' => $_POST['descripcion'],
        ':usuario' => $_SESSION['nombre']
    ]);

    header("Location: listar.php");
    exit();
}

?>
<!DOCTYPE html>
<html>
<head>

<title>Agregar Categoría</title>

<link rel="stylesheet" href="../css/estilos.css">

</head>
<body>

<div class="contenedor">

<h1>Agregar Categoría</h1>

<form method="POST">


Nombre<br>
<input type="text"
       name="nombre_categoria"
       required>

<br><br>

Descripción<br>
<input type="text"
       name="descripcion">

<br><br>

<button class="btn btn-agregar"
        type="submit"
        name="guardar">

💾 Guardar

</button>

<a class="btn btn-editar"
   href="listar.php">

⬅ Volver

</a>

</form>

</div>

</body>
</html>