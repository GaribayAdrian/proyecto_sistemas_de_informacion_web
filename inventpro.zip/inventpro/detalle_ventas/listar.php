<?php

session_start();

require_once "../conexion.php";

$sql = "SELECT
            dv.id_detalle_venta,
            v.id_venta,
            p.nombre_producto,
            dv.cantidad,
            dv.precio_unitario,
            dv.subtotal
        FROM detalle_ventas dv
        INNER JOIN ventas v
            ON dv.id_venta = v.id_venta
        INNER JOIN productos p
            ON dv.id_producto = p.id_producto
        ORDER BY dv.id_detalle_venta";

$stmt = $conexion->prepare($sql);
$stmt->execute();

$detalles = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html>

<head>

<title>Detalle de Ventas</title>

<link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

<h1>Detalle de Ventas</h1>

<a
class="btn btn-agregar"
href="agregar.php">

➕ Agregar Detalle

</a>

<a
class="btn btn-home"
href="../dashboard.php">

🏠 Inicio

</a>

<br><br>

<table>

<tr>

<th>Venta</th>
<th>Producto</th>
<th>Cantidad</th>
<th>Precio Unitario</th>
<th>Subtotal</th>
<th>Eliminar</th>

</tr>

<?php foreach($detalles as $detalle){ ?>

<tr>

<td>

<?= $detalle['id_venta']; ?>

</td>

<td>

<?= $detalle['nombre_producto']; ?>

</td>

<td>

<?= $detalle['cantidad']; ?>

</td>

<td>

$<?= number_format($detalle['precio_unitario'],2); ?>

</td>

<td>

$<?= number_format($detalle['subtotal'],2); ?>

</td>

<td>


<a
class="btn btn-eliminar"
href="eliminar.php?id=<?= $detalle['id_detalle_venta']; ?>">

🗑 Eliminar

</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</body>

</html>