<?php

session_start();

require_once "../conexion.php";

// Obtener clientes
$sqlClientes = "SELECT *
                FROM clientes
                ORDER BY nombre_cliente";

$stmtClientes = $conexion->prepare($sqlClientes);
$stmtClientes->execute();

$clientes = $stmtClientes->fetchAll(PDO::FETCH_ASSOC);

if(isset($_POST['guardar'])){

    $sql = "INSERT INTO ventas
            (
                fecha,
                total_venta,
                id_cliente,
                id_usuario,
                usuario_creacion
            )
            VALUES
            (
                :fecha,
                :total,
                :cliente,
                :id_usuario,
                :usuario
            )";

    $stmt = $conexion->prepare($sql);

    $stmt->execute([

        ':fecha' => $_POST['fecha'],
        ':total' => $_POST['total_venta'],
        ':cliente' => $_POST['id_cliente'],
        ':id_usuario' => $_SESSION['id_usuario'],
        ':usuario' => $_SESSION['nombre']

    ]);

    header("Location: listar.php");
    exit();

}

?>

<!DOCTYPE html>
<html>

<head>

<title>Agregar Venta</title>

<link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

<h1>Agregar Venta</h1>

<form method="POST">

Fecha

<br>

<input
type="date"
name="fecha"
required>

<br><br>

Cliente

<br>

<select
name="id_cliente"
required>

<option value="">
Seleccione un cliente
</option>

<?php foreach($clientes as $cliente){ ?>

<option
value="<?= $cliente['id_cliente']; ?>">

<?= $cliente['nombre_cliente']; ?>

</option>

<?php } ?>

</select>

<br><br>

Total

<br>

<input
type="number"
step="0.01"
name="total_venta"
required>

<br><br>

<button
class="btn btn-agregar"
type="submit"
name="guardar">

💾 Guardar

</button>

<a
class="btn btn-editar"
href="listar.php">

⬅ Volver

</a>

<a
class="btn btn-home"
href="../dashboard.php">

🏠 Inicio

</a>

</form>

</div>

</body>

</html>