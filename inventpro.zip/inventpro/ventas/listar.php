<?php

session_start();

require_once "../conexion.php";

$sql = "SELECT
            v.*,
            c.nombre_cliente,
            u.nombre
        FROM ventas v
        LEFT JOIN clientes c
        ON v.id_cliente = c.id_cliente
        LEFT JOIN usuarios u
        ON v.id_usuario = u.id_usuario
        ORDER BY v.id_venta";

$stmt = $conexion->prepare($sql);
$stmt->execute();

$ventas = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html>

<head>

<title>Ventas</title>

<link rel="stylesheet" href="../css/estilos.css">

</head>

<body>

<div class="contenedor">

<h1>Historial de Ventas</h1>

<a class="btn btn-agregar"
href="agregar.php">

➕ Nueva Venta

</a>

<a class="btn btn-home"
href="../dashboard.php">

🏠 Inicio

</a>

<br><br>

<table>

<tr>

<th>Fecha</th>
<th>Cliente</th>
<th>Total</th>
<th>Registró</th>
<th>Ver</th>
<th>Eliminar</th>

</tr>

<?php foreach($ventas as $venta){ ?>

<tr>

<td><?= $venta['fecha']; ?></td>

<td><?= $venta['nombre_cliente']; ?></td>

<td>$<?= number_format($venta['total_venta'],2); ?></td>

<td><?= $venta['nombre']; ?></td>

<td>


<a
class="btn btn-editar"
href="ver.php?id=<?= $venta['id_venta']; ?>">

👁 Ver

</a>

</td>
<td>
<a
class="btn btn-eliminar"
href="eliminar.php?id=<?= $venta['id_venta']; ?>">

🗑 Eliminar

</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</body>

</html>